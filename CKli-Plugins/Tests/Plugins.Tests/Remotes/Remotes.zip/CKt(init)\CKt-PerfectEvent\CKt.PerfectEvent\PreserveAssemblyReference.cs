using System;

namespace CKt.PerfectEvent;

public record PreserveAssemblyReference( CKt.ActivityMonitor.PreserveAssemblyReference ActivityMonitor );
